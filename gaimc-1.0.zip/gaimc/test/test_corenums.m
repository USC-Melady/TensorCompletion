function test_corenums

end